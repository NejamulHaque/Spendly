// ============================================================
//  SPENDLY — auth.js
//  Firebase Auth Logic (Email/Password + Google)
// ============================================================

import { auth, provider } from "./firebase-config.js";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// Watch login/logout state — calls onLogin(user) or onLogout()
export function watchAuthState(onLogin, onLogout) {
  onAuthStateChanged(auth, user => user ? onLogin(user) : onLogout());
}

// Sign up with email + password
export async function signUpEmail(name, email, password) {
  if (!name.trim())        throw new Error("Please enter your full name.");
  if (!email.trim())       throw new Error("Please enter your email.");
  if (password.length < 6) throw new Error("Password must be at least 6 characters.");

  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, { displayName: name.trim() });
  return cred.user;
}

// Sign in with email + password
export async function signInEmail(email, password) {
  if (!email.trim()) throw new Error("Please enter your email.");
  if (!password)     throw new Error("Please enter your password.");

  const cred = await signInWithEmailAndPassword(auth, email, password);
  return cred.user;
}

// Sign in with Google popup
export async function signInGoogle() {
  const cred = await signInWithPopup(auth, provider);
  return cred.user;
}

// Sign out
export async function logOut() {
  await signOut(auth);
}

// Send password reset email
export async function resetPassword(email) {
  if (!email.trim()) throw new Error("Please enter your email address.");
  await sendPasswordResetEmail(auth, email);
}

// Turn Firebase error codes into human-readable messages
export function friendlyError(code) {
  const map = {
    "auth/email-already-in-use":   "This email is already registered. Try signing in.",
    "auth/invalid-email":          "Please enter a valid email address.",
    "auth/user-not-found":         "No account found with this email.",
    "auth/wrong-password":         "Incorrect password. Please try again.",
    "auth/invalid-credential":     "Invalid email or password.",
    "auth/too-many-requests":      "Too many attempts. Please wait and try again.",
    "auth/network-request-failed": "Network error. Check your connection.",
    "auth/popup-closed-by-user":   "Google sign-in was cancelled.",
    "auth/popup-blocked":          "Pop-ups are blocked. Please allow pop-ups for this site.",
    "auth/weak-password":          "Password too weak. Use at least 6 characters.",
  };
  return map[code] || "Something went wrong. Please try again.";
}

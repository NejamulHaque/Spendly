// ============================================================
//  SPENDLY — firebase-config.js
//  ⚠️  PASTE YOUR FIREBASE CREDENTIALS BELOW
//  See SETUP-GUIDE.md for step-by-step instructions
// ============================================================

import { initializeApp }               from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, GoogleAuthProvider } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore }                from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// ── Step 1: Replace every value below with your own project config ──
// Get it from: Firebase Console → Project Settings → Your Apps → SDK setup → Config
const firebaseConfig = {
  apiKey:            "PASTE_YOUR_API_KEY_HERE",
  authDomain:        "PASTE_YOUR_AUTH_DOMAIN_HERE",
  projectId:         "PASTE_YOUR_PROJECT_ID_HERE",
  storageBucket:     "PASTE_YOUR_STORAGE_BUCKET_HERE",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID_HERE",
  appId:             "PASTE_YOUR_APP_ID_HERE",
};

// ── DO NOT EDIT BELOW THIS LINE ──────────────────────────────
const app      = initializeApp(firebaseConfig);
const auth     = getAuth(app);
const db       = getFirestore(app);
const provider = new GoogleAuthProvider();

export { auth, db, provider };

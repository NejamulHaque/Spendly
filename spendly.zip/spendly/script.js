/* ============================================================
   SPENDLY — script.js
   Smart Expense Tracker — Complete Application Logic
   ============================================================ */

'use strict';

/* ── State ─────────────────────────────────────────────────── */
let DB = {
  transactions: [],
  budgets:      {},   // { category: { limit, alertPct } }
  goals:        [],
  recurring:    [],
  settings: {
    name:           '',
    currency:       'INR',
    monthlyIncome:  0,
    budgetAlerts:   true,
    compactView:    false,
  }
};

/* ── Constants ─────────────────────────────────────────────── */
const CATS_EXPENSE = ['Food','Transportation','Housing','Utilities','Healthcare','Entertainment','Education','Shopping','Other'];
const CATS_INCOME  = ['Salary','Freelance','Business','Investment','Gift','Other'];

const CAT_COLORS = {
  Food:'#ffd166',     Transportation:'#a78bfa', Housing:'#00d4aa',
  Utilities:'#2dd4bf',Healthcare:'#f472b6',      Entertainment:'#fb7185',
  Education:'#fb923c',Shopping:'#34d399',         Other:'#94a3b8',
  Salary:'#00d4aa',   Freelance:'#7c6aff',        Business:'#38d9a9',
  Investment:'#ffd166',Gift:'#f472b6',
};
const CAT_ICONS = {
  Food:'fa-utensils',       Transportation:'fa-car',         Housing:'fa-house',
  Utilities:'fa-bolt',      Healthcare:'fa-heart-pulse',      Entertainment:'fa-clapperboard',
  Education:'fa-graduation-cap', Shopping:'fa-bag-shopping', Other:'fa-tag',
  Salary:'fa-briefcase',    Freelance:'fa-laptop',            Business:'fa-chart-pie',
  Investment:'fa-trending-up', Gift:'fa-gift',
};
const CAT_BADGES = {
  Food:'badge-food',           Transportation:'badge-transport', Housing:'badge-housing',
  Utilities:'badge-utilities', Healthcare:'badge-health',         Entertainment:'badge-entertainment',
  Education:'badge-education', Shopping:'badge-shopping',         Other:'badge-other',
  Salary:'badge-salary',       Freelance:'badge-freelance',       Business:'badge-business',
  Investment:'badge-investment',Gift:'badge-gift',
};
const CURRENCIES = {
  INR:{ sym:'₹', locale:'en-IN' }, USD:{ sym:'$',   locale:'en-US' },
  EUR:{ sym:'€', locale:'de-DE' }, GBP:{ sym:'£',   locale:'en-GB' },
  JPY:{ sym:'¥', locale:'ja-JP' }, CAD:{ sym:'CA$', locale:'en-CA' },
  AUD:{ sym:'A$',locale:'en-AU' }, SGD:{ sym:'S$',  locale:'en-SG' },
  BDT:{ sym:'৳', locale:'en-BD' },
};

let chartInstances    = {};
let currentModalType  = 'expense';
let currentRecType    = 'expense';

/* ── Persistence ───────────────────────────────────────────── */
const STORAGE_KEY = 'spendly_v3';

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(DB));
}

function loadDB() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      DB = { ...DB, ...saved, settings: { ...DB.settings, ...(saved.settings || {}) } };
    }
  } catch (e) {
    console.warn('Spendly: Could not load saved data.', e);
  }
}

/* ── Currency Helpers ──────────────────────────────────────── */
function sym(c) {
  return (CURRENCIES[c || DB.settings.currency] || CURRENCIES.INR).sym;
}

function fmt(n, c) {
  const cur  = c || DB.settings.currency;
  const info = CURRENCIES[cur] || CURRENCIES.INR;
  try {
    return new Intl.NumberFormat(info.locale, {
      style: 'currency',
      currency: cur,
      minimumFractionDigits: cur === 'JPY' ? 0 : 2,
      maximumFractionDigits: cur === 'JPY' ? 0 : 2,
    }).format(n);
  } catch (e) {
    return info.sym + Number(n).toFixed(2);
  }
}

function setCurrency(val) {
  DB.settings.currency = val;
  persist();
  ['global-currency', 's-currency'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  });
  document.querySelectorAll('[id$="-sym"]').forEach(el => el.textContent = sym());
  renderAll();
}

/* ── Page Routing ──────────────────────────────────────────── */
const PAGE_TITLES = {
  dashboard:    'Dashboard',
  transactions: 'Transactions',
  budgets:      'Budgets',
  goals:        'Savings Goals',
  recurring:    'Recurring',
  analytics:    'Analytics',
  settings:     'Settings',
};

function nav(el, pageId) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + pageId).classList.add('active');
  document.getElementById('page-title').textContent = PAGE_TITLES[pageId] || '';
  if (pageId === 'analytics') setTimeout(renderAnalytics, 80);
  if (pageId === 'dashboard')  renderDashboard();
  document.getElementById('sidebar').classList.remove('open');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

/* ── Transaction Modal ─────────────────────────────────────── */
function openModal(editId) {
  const overlay = document.getElementById('modal-overlay');
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';

  if (editId) {
    const tx = DB.transactions.find(t => t.id === editId);
    if (!tx) return;
    document.getElementById('modal-title').textContent      = 'Edit Transaction';
    document.getElementById('modal-save-label').textContent = 'Update';
    document.getElementById('m-edit-id').value   = editId;
    setType(tx.type);
    document.getElementById('m-date').value    = tx.date;
    document.getElementById('m-amount').value  = tx.amount;
    document.getElementById('m-desc').value    = tx.description || '';
    document.getElementById('m-tags').value    = (tx.tags || []).join(', ');
    document.getElementById('m-payment').value = tx.payment || '';
    document.getElementById('m-notes').value   = tx.notes || '';
    setTimeout(() => { document.getElementById('m-cat').value = tx.category; }, 50);
  } else {
    document.getElementById('modal-title').textContent      = 'Add Transaction';
    document.getElementById('modal-save-label').textContent = 'Save';
    document.getElementById('m-edit-id').value  = '';
    setType('expense');
    document.getElementById('m-date').value    = todayStr();
    document.getElementById('m-amount').value  = '';
    document.getElementById('m-desc').value    = '';
    document.getElementById('m-tags').value    = '';
    document.getElementById('m-payment').value = '';
    document.getElementById('m-notes').value   = '';
  }
  setTimeout(() => document.getElementById('m-amount').focus(), 120);
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  document.body.style.overflow = '';
}

function handleOverlayClick(e) {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
}

/* ── Confirm Dialog ────────────────────────────────────────── */
function openConfirm(title, msg, onConfirm) {
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-msg').textContent   = msg;
  document.getElementById('confirm-btn').onclick = () => { onConfirm(); closeConfirm(); };
  document.getElementById('confirm-overlay').classList.add('open');
}

function closeConfirm() {
  document.getElementById('confirm-overlay').classList.remove('open');
}

/* ── Type Toggle ───────────────────────────────────────────── */
function setType(type) {
  currentModalType = type;
  document.getElementById('tt-exp').classList.toggle('active', type === 'expense');
  document.getElementById('tt-inc').classList.toggle('active', type === 'income');
  const cats = type === 'expense' ? CATS_EXPENSE : CATS_INCOME;
  const sel  = document.getElementById('m-cat');
  sel.innerHTML = cats.map(c => `<option value="${c}">${catEmoji(c)} ${c}</option>`).join('');
}

function catEmoji(c) {
  const m = {
    Food:'🍽️', Transportation:'🚗', Housing:'🏠', Utilities:'⚡',
    Healthcare:'🏥', Entertainment:'🎬', Education:'📚', Shopping:'🛍️',
    Other:'📦', Salary:'💼', Freelance:'💻', Business:'📊',
    Investment:'📈', Gift:'🎁',
  };
  return m[c] || '•';
}

/* ── Save Transaction ──────────────────────────────────────── */
function saveTransaction() {
  const date    = document.getElementById('m-date').value;
  const cat     = document.getElementById('m-cat').value;
  const amount  = parseFloat(document.getElementById('m-amount').value);
  const desc    = document.getElementById('m-desc').value.trim();
  const tags    = document.getElementById('m-tags').value.split(',').map(t => t.trim()).filter(Boolean);
  const payment = document.getElementById('m-payment').value;
  const notes   = document.getElementById('m-notes').value.trim();
  const editId  = document.getElementById('m-edit-id').value;

  if (!date)               { toast('Please select a date', 'error'); return; }
  if (!cat)                { toast('Please select a category', 'error'); return; }
  if (!amount || amount <= 0) { toast('Please enter a valid amount', 'error'); return; }

  const record = { date, category: cat, amount, description: desc, tags, payment, notes, type: currentModalType };

  if (editId) {
    const i = DB.transactions.findIndex(t => t.id === editId);
    if (i > -1) DB.transactions[i] = { ...DB.transactions[i], ...record, updatedAt: Date.now() };
    toast('Transaction updated ✓', 'success');
  } else {
    DB.transactions.unshift({
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
      ...record,
    });
    toast('Transaction saved ✓', 'success');
  }

  persist();
  closeModal();
  renderAll();
}

function deleteTransaction(id) {
  const tx    = DB.transactions.find(t => t.id === id);
  const label = tx ? `"${tx.description || tx.category}" (${fmt(tx.amount)})` : 'this transaction';
  openConfirm('Delete Transaction', `Are you sure you want to delete ${label}?`, () => {
    DB.transactions = DB.transactions.filter(t => t.id !== id);
    persist(); renderAll();
    toast('Transaction deleted', 'info');
  });
}

function confirmClearAll() {
  openConfirm(
    'Delete All Data',
    'This will permanently delete ALL transactions, budgets, goals, and recurring items. This cannot be undone!',
    () => {
      DB.transactions = []; DB.budgets = {}; DB.goals = []; DB.recurring = [];
      persist(); renderAll();
      toast('All data cleared', 'info');
    }
  );
}

function clearFilters() {
  ['f-search', 'f-type', 'f-cat', 'f-from', 'f-to'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('f-sort').value = 'date-desc';
  renderTransactions();
}

/* ── Budgets ───────────────────────────────────────────────── */
function saveBudget() {
  const cat      = document.getElementById('b-cat').value;
  const limit    = parseFloat(document.getElementById('b-limit').value);
  const alertPct = parseInt(document.getElementById('b-alert-pct').value);
  if (!cat || isNaN(limit) || limit <= 0) { toast('Enter a valid budget limit', 'error'); return; }
  DB.budgets[cat] = { limit, alertPct };
  persist(); renderBudgets();
  document.getElementById('b-limit').value = '';
  toast(`Budget set for ${cat} ✓`, 'success');
}

function deleteBudget(cat) {
  openConfirm('Remove Budget', `Remove the budget for "${cat}"?`, () => {
    delete DB.budgets[cat]; persist(); renderBudgets();
    toast(`Budget for ${cat} removed`, 'info');
  });
}

/* ── Goals ─────────────────────────────────────────────────── */
function saveGoal() {
  const name     = document.getElementById('g-name').value.trim();
  const target   = parseFloat(document.getElementById('g-target').value);
  const saved    = parseFloat(document.getElementById('g-saved').value) || 0;
  const date     = document.getElementById('g-date').value;
  const priority = document.getElementById('g-priority').value;
  const desc     = document.getElementById('g-desc').value.trim();

  if (!name)               { toast('Enter a goal name', 'error'); return; }
  if (!target || target <= 0) { toast('Enter a valid target amount', 'error'); return; }

  DB.goals.push({ id: `g_${Date.now()}`, name, target, saved, date, priority, desc, createdAt: Date.now() });
  persist(); renderGoals();
  ['g-name','g-target','g-saved','g-date','g-desc'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('g-priority').value = 'medium';
  toast(`Goal "${name}" added ✓`, 'success');
}

function deleteGoal(id) {
  const g = DB.goals.find(g => g.id === id);
  openConfirm('Delete Goal', `Delete goal "${g?.name || 'this goal'}"?`, () => {
    DB.goals = DB.goals.filter(g => g.id !== id); persist(); renderGoals();
    toast('Goal deleted', 'info');
  });
}

function updateGoalSaved(id) {
  const g = DB.goals.find(g => g.id === id);
  if (!g) return;
  const val = parseFloat(prompt(`Update saved amount for "${g.name}" (current: ${fmt(g.saved)}):`));
  if (isNaN(val) || val < 0) return;
  const i = DB.goals.findIndex(g => g.id === id);
  if (i > -1) { DB.goals[i].saved = val; persist(); renderGoals(); toast('Goal updated ✓', 'success'); }
}

/* ── Recurring ─────────────────────────────────────────────── */
function setRecType(type) {
  currentRecType = type;
  document.getElementById('rt-exp').classList.toggle('active', type === 'expense');
  document.getElementById('rt-inc').classList.toggle('active', type === 'income');
}

function saveRecurring() {
  const name   = document.getElementById('r-name').value.trim();
  const cat    = document.getElementById('r-cat').value;
  const freq   = document.getElementById('r-freq').value;
  const amount = parseFloat(document.getElementById('r-amount').value);
  const date   = document.getElementById('r-date').value;

  if (!name)               { toast('Enter a name', 'error'); return; }
  if (!amount || amount <= 0) { toast('Enter a valid amount', 'error'); return; }

  DB.recurring.push({ id: `r_${Date.now()}`, name, category: cat, frequency: freq, amount, date, type: currentRecType, createdAt: Date.now() });
  persist(); renderRecurring();
  ['r-name','r-amount','r-date'].forEach(id => document.getElementById(id).value = '');
  toast(`"${name}" added ✓`, 'success');
}

function deleteRecurring(id) {
  const r = DB.recurring.find(r => r.id === id);
  openConfirm('Delete Recurring', `Delete "${r?.name || 'this item'}"?`, () => {
    DB.recurring = DB.recurring.filter(r => r.id !== id); persist(); renderRecurring();
    toast('Recurring removed', 'info');
  });
}

/* ── Settings ──────────────────────────────────────────────── */
function saveSettings() {
  DB.settings.name          = document.getElementById('s-name').value.trim();
  DB.settings.monthlyIncome = parseFloat(document.getElementById('s-income').value) || 0;
  DB.settings.budgetAlerts  = document.getElementById('pref-alerts').checked;
  DB.settings.compactView   = document.getElementById('pref-compact').checked;
  persist();
  updateGreeting();
}

function applySettings() {
  const { name, currency, monthlyIncome, budgetAlerts, compactView } = DB.settings;
  ['global-currency','s-currency'].forEach(id => { const el = document.getElementById(id); if (el) el.value = currency; });
  const sName = document.getElementById('s-name');       if (sName)     sName.value     = name || '';
  const sInc  = document.getElementById('s-income');     if (sInc)      sInc.value      = monthlyIncome || '';
  const pAlerts = document.getElementById('pref-alerts');if (pAlerts)   pAlerts.checked = budgetAlerts !== false;
  const pComp   = document.getElementById('pref-compact');if (pComp)   pComp.checked   = !!compactView;
  document.querySelectorAll('[id$="-sym"]').forEach(el => el.textContent = sym());
}

/* ── Export / Import ───────────────────────────────────────── */
function exportCSV() {
  if (!DB.transactions.length) { toast('No transactions to export', 'error'); return; }
  const rows = [
    ['Date','Type','Category','Amount','Currency','Description','Tags','Payment','Notes'],
    ...DB.transactions.map(t => [
      t.date, t.type, t.category, t.amount, DB.settings.currency,
      `"${(t.description || '').replace(/"/g,'""')}"`,
      `"${(t.tags || []).join(';')}"`,
      t.payment || '',
      `"${(t.notes || '').replace(/"/g,'""')}"`
    ])
  ];
  const csv = rows.map(r => r.join(',')).join('\n');
  download(`spendly_${todayStr()}.csv`, 'text/csv;charset=utf-8', csv);
  toast('CSV exported ✓', 'success');
}

function exportJSON() {
  download(`spendly_backup_${todayStr()}.json`, 'application/json', JSON.stringify(DB, null, 2));
  toast('Backup exported ✓', 'success');
}

function importJSON(input) {
  const file = input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.transactions) {
        openConfirm('Import Backup', 'This will REPLACE all your current data. Continue?', () => {
          DB = { ...DB, ...data, settings: { ...DB.settings, ...(data.settings || {}) } };
          persist(); applySettings(); renderAll();
          toast('Data imported ✓', 'success');
        });
      } else { toast('Invalid backup file', 'error'); }
    } catch (err) { toast('Could not read file', 'error'); }
  };
  reader.readAsText(file);
  input.value = '';
}

function download(name, type, content) {
  const a = document.createElement('a');
  a.href     = URL.createObjectURL(new Blob([content], { type }));
  a.download = name;
  a.click();
}

/* ── Render All ────────────────────────────────────────────── */
function renderAll() {
  renderDashboard();
  renderTransactions();
  renderBudgets();
  renderGoals();
  renderRecurring();
  updateBadge();
  renderAbout();
}

function updateBadge() {
  const el = document.getElementById('tx-count-badge');
  if (el) el.textContent = DB.transactions.length;
}

/* ── Greeting ──────────────────────────────────────────────── */
function updateGreeting() {
  const h = new Date().getHours();
  const greet = h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const name  = DB.settings.name;
  const gEl   = document.getElementById('greeting');
  const gSub  = document.getElementById('greeting-sub');
  if (gEl) gEl.textContent = name ? `${greet}, ${name} 👋` : `${greet} 👋`;
  if (gSub) gSub.textContent = new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
}

/* ── Dashboard ─────────────────────────────────────────────── */
function renderDashboard() {
  updateGreeting();
  const now  = new Date();
  const curM = now.getMonth(), curY = now.getFullYear();

  const thisMonth   = DB.transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === curM && d.getFullYear() === curY;
  });
  const monthIncome = thisMonth.filter(t => t.type === 'income').reduce((s,t) => s + t.amount, 0);
  const monthSpent  = thisMonth.filter(t => t.type === 'expense').reduce((s,t) => s + t.amount, 0);
  const allIncome   = DB.transactions.filter(t => t.type === 'income').reduce((s,t) => s + t.amount, 0);
  const allSpent    = DB.transactions.filter(t => t.type === 'expense').reduce((s,t) => s + t.amount, 0);
  const balance     = allIncome - allSpent;
  const effIncome   = monthIncome || DB.settings.monthlyIncome;
  const savingsRate = effIncome > 0 ? Math.max(0, Math.round(((effIncome - monthSpent) / effIncome) * 100)) : 0;

  const set = (id, val, color) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = val;
    if (color) el.style.color = color;
  };

  set('s-income',  fmt(monthIncome), 'var(--income)');
  set('s-income-sub', `${thisMonth.filter(t => t.type === 'income').length} transactions`);
  set('s-spent',   fmt(monthSpent),  'var(--expense)');
  set('s-spent-sub', `${thisMonth.filter(t => t.type === 'expense').length} transactions`);
  set('s-balance', fmt(balance), balance >= 0 ? 'var(--income)' : 'var(--expense)');
  set('s-rate',    savingsRate + '%');
  set('s-rate-sub', effIncome > 0 ? `${fmt(Math.max(0, effIncome - monthSpent))} saved` : 'Set income in Settings');

  renderInsights(thisMonth, monthSpent, effIncome);

  const piePeriod = document.getElementById('pie-period')?.value || 'month';
  renderPieChart(filterByPeriod(DB.transactions.filter(t => t.type === 'expense'), piePeriod));
  renderBarChart();
  renderRecent();
}

function filterByPeriod(arr, period) {
  const now = new Date(), m = now.getMonth(), y = now.getFullYear();
  if (period === 'month')  return arr.filter(t => { const d = new Date(t.date); return d.getMonth() === m && d.getFullYear() === y; });
  if (period === '3month') { const cut = new Date(y, m - 2, 1); return arr.filter(t => new Date(t.date) >= cut); }
  if (period === 'year')   return arr.filter(t => new Date(t.date).getFullYear() === y);
  return arr;
}

function renderInsights(thisMonth, spent, income) {
  const el = document.getElementById('insights-row');
  if (!el) return;

  const catTotals = {};
  thisMonth.filter(t => t.type === 'expense').forEach(t => catTotals[t.category] = (catTotals[t.category] || 0) + t.amount);
  const top  = Object.entries(catTotals).sort((a,b) => b[1] - a[1])[0];
  const day  = new Date().getDate();
  const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
  const projected   = day > 0 ? (spent / day) * daysInMonth : 0;

  el.innerHTML = `
    <div class="insight">
      <div class="insight-icon"><i class="fas fa-fire-flame-curved"></i></div>
      <div>
        <h4>Top Category: ${top ? top[0] : 'No expenses yet'}</h4>
        <p>${top ? `${fmt(top[1])} spent on ${top[0]} this month (${Math.round(top[1] / spent * 100) || 0}% of total)` : 'Add your expenses to see insights'}</p>
      </div>
    </div>
    <div class="insight" style="background:linear-gradient(135deg,rgba(124,106,255,.06),rgba(255,107,107,.04));border-color:rgba(124,106,255,.12)">
      <div class="insight-icon" style="background:rgba(124,106,255,.12);color:var(--accent2)"><i class="fas fa-chart-line"></i></div>
      <div>
        <h4>Projected Month: ${fmt(projected)}</h4>
        <p>Daily avg ${fmt(day > 0 ? spent / day : 0)} · ${daysInMonth - day} days left this month</p>
      </div>
    </div>
  `;
}

function renderRecent() {
  const el = document.getElementById('recent-list');
  if (!el) return;
  const recent = [...DB.transactions].sort((a,b) => new Date(b.date) - new Date(a.date)).slice(0, 7);
  if (!recent.length) {
    el.innerHTML = `<div class="empty-state" style="padding:30px 0"><div class="empty-icon"><i class="fas fa-receipt"></i></div><h3>No transactions yet</h3><p>Add your first transaction to get started</p></div>`;
    return;
  }
  el.innerHTML = recent.map(t => `
    <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid var(--border);cursor:pointer" onclick="openModal('${t.id}')">
      <div style="width:34px;height:34px;border-radius:9px;background:${CAT_COLORS[t.category] || '#64748b'}18;display:flex;align-items:center;justify-content:center;color:${CAT_COLORS[t.category] || '#94a3b8'};font-size:.82rem;flex-shrink:0">
        <i class="fas ${CAT_ICONS[t.category] || 'fa-tag'}"></i>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:.83rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(t.description || t.category)}</div>
        <div style="font-size:.68rem;color:var(--muted);margin-top:1px">${fmtDate(t.date)} · ${t.category}</div>
      </div>
      <div style="font-family:var(--fm);font-size:.82rem;font-weight:700;color:${t.type === 'income' ? 'var(--income)' : 'var(--expense)'};flex-shrink:0">
        ${t.type === 'income' ? '+' : '-'}${fmt(t.amount)}
      </div>
    </div>
  `).join('');
}

/* ── Pie Chart ─────────────────────────────────────────────── */
function renderPieChart(expenses) {
  const catTotals = {};
  expenses.forEach(t => catTotals[t.category] = (catTotals[t.category] || 0) + t.amount);
  const total  = Object.values(catTotals).reduce((s,v) => s + v, 0);
  const labels = Object.keys(catTotals);
  const data   = Object.values(catTotals);
  const colors = labels.map(l => CAT_COLORS[l] || '#64748b');

  destroyChart('pie');
  const ctx = document.getElementById('chart-pie');
  if (!ctx) return;
  chartInstances.pie = new Chart(ctx, {
    type: 'doughnut',
    data: { labels, datasets: [{ data, backgroundColor: colors.map(c => c + 'bb'), borderColor: colors, borderWidth: 2, hoverOffset: 10 }] },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '68%',
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1a2035', titleColor: '#e2e8f0', bodyColor: '#94a3b8',
          borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
          callbacks: { label: c => `${c.label}: ${fmt(c.raw)} (${total ? Math.round(c.raw / total * 100) : 0}%)` }
        }
      }
    }
  });

  const leg = document.getElementById('pie-legend');
  if (!leg) return;
  if (!labels.length) { leg.innerHTML = '<div style="font-size:.78rem;color:var(--muted);text-align:center;padding:8px 0">No data for this period</div>'; return; }
  leg.innerHTML = labels.map((l,i) => `
    <div class="legend-item">
      <div class="legend-dot" style="background:${colors[i]}"></div>
      <span style="flex:1">${l}</span>
      <div class="legend-bar-wrap"><div class="legend-bar"><div class="legend-fill" style="width:${total ? Math.round(data[i] / total * 100) : 0}%;background:${colors[i]}"></div></div></div>
      <span class="legend-pct">${total ? Math.round(data[i] / total * 100) : 0}%</span>
      <span class="legend-amt">${fmt(data[i])}</span>
    </div>
  `).join('');
}

/* ── Bar Chart ─────────────────────────────────────────────── */
function renderBarChart() {
  const months = getLast6Months();
  const incArr = months.map(m => getMonthTotal(m, 'income'));
  const expArr = months.map(m => getMonthTotal(m, 'expense'));

  destroyChart('bar');
  const ctx = document.getElementById('chart-bar');
  if (!ctx) return;
  chartInstances.bar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: months.map(m => m.label),
      datasets: [
        { label: 'Income',   data: incArr, backgroundColor: 'rgba(0,212,170,.5)',  borderColor: '#00d4aa', borderWidth: 2, borderRadius: 6, borderSkipped: false },
        { label: 'Expenses', data: expArr, backgroundColor: 'rgba(255,107,107,.5)',borderColor: '#ff6b6b', borderWidth: 2, borderRadius: 6, borderSkipped: false },
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: '#94a3b8', font: { family: 'Outfit', size: 11 } } },
        tooltip: {
          backgroundColor: '#1a2035', titleColor: '#e2e8f0', bodyColor: '#94a3b8',
          borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
          callbacks: { label: c => `${c.dataset.label}: ${fmt(c.raw)}` }
        }
      },
      scales: {
        x: { ticks: { color: '#64748b', font: { family: 'Outfit' } }, grid: { color: 'rgba(255,255,255,.04)' } },
        y: { ticks: { color: '#64748b', font: { family: 'Outfit' }, callback: v => sym() + abbreviate(v) }, grid: { color: 'rgba(255,255,255,.04)' }, beginAtZero: true }
      }
    }
  });
}

/* ── Transactions Table ────────────────────────────────────── */
function renderTransactions() {
  populateCatFilter();

  const search = (document.getElementById('f-search')?.value || '').toLowerCase().trim();
  const type   = document.getElementById('f-type')?.value || '';
  const cat    = document.getElementById('f-cat')?.value  || '';
  const from   = document.getElementById('f-from')?.value || '';
  const to     = document.getElementById('f-to')?.value   || '';
  const sort   = document.getElementById('f-sort')?.value || 'date-desc';

  let list = [...DB.transactions];
  if (type)   list = list.filter(t => t.type === type);
  if (cat)    list = list.filter(t => t.category === cat);
  if (from)   list = list.filter(t => t.date >= from);
  if (to)     list = list.filter(t => t.date <= to);
  if (search) list = list.filter(t =>
    (t.description || '').toLowerCase().includes(search) ||
    (t.category    || '').toLowerCase().includes(search) ||
    (t.notes       || '').toLowerCase().includes(search) ||
    (t.tags        || []).join(' ').toLowerCase().includes(search)
  );

  const [sk, sd] = sort.split('-');
  list.sort((a,b) => {
    const v = sk === 'date' ? new Date(a.date) - new Date(b.date) : a.amount - b.amount;
    return sd === 'desc' ? -v : v;
  });

  const tbody  = document.getElementById('tx-body');
  const empty  = document.getElementById('tx-empty');
  const footer = document.getElementById('tx-footer');
  if (!tbody) return;

  if (!list.length) {
    tbody.innerHTML = ''; empty.style.display = 'block'; footer.style.display = 'none'; return;
  }
  empty.style.display = 'none'; footer.style.display = 'flex';

  const totalFiltered = list.reduce((s,t) => s + (t.type === 'income' ? t.amount : -t.amount), 0);
  const txCount = document.getElementById('tx-count-text');
  const txTotal = document.getElementById('tx-total-text');
  if (txCount) txCount.textContent = `${list.length} record${list.length !== 1 ? 's' : ''} shown`;
  if (txTotal) txTotal.textContent = `Net: ${totalFiltered >= 0 ? '+' : ''}${fmt(totalFiltered)}`;

  tbody.innerHTML = list.map(t => `
    <tr>
      <td style="white-space:nowrap;font-size:.78rem;color:var(--muted2)">${fmtDate(t.date)}</td>
      <td><span class="badge ${t.type === 'income' ? 'badge-income-type' : 'badge-expense-type'}">${t.type === 'income' ? '↓ Income' : '↑ Expense'}</span></td>
      <td><span class="badge ${CAT_BADGES[t.category] || 'badge-other'}"><i class="fas ${CAT_ICONS[t.category] || 'fa-tag'} fa-xs"></i> ${t.category}</span></td>
      <td style="max-width:220px">
        <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500">${escHtml(t.description || '—')}</div>
        ${t.notes ? `<div style="font-size:.65rem;color:var(--muted);margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escHtml(t.notes)}">${escHtml(t.notes)}</div>` : ''}
      </td>
      <td style="min-width:80px">${(t.tags || []).map(g => `<span class="tag">${escHtml(g)}</span>`).join(' ')}</td>
      <td style="font-size:.72rem;color:var(--muted)">${escHtml(t.payment || '—')}</td>
      <td style="text-align:right" class="amount-col ${t.type === 'income' ? 'col-income' : 'col-expense'}">
        ${t.type === 'income' ? '+' : '-'}${fmt(t.amount)}
      </td>
      <td style="text-align:right;white-space:nowrap">
        <button class="btn btn-ghost btn-icon btn-sm" onclick="openModal('${t.id}')" title="Edit"><i class="fas fa-pencil"></i></button>
        <button class="btn btn-danger btn-icon btn-sm" onclick="deleteTransaction('${t.id}')" title="Delete"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
  `).join('');
}

function populateCatFilter() {
  const sel = document.getElementById('f-cat');
  if (!sel) return;
  const cats = [...new Set(DB.transactions.map(t => t.category))].sort();
  const cur  = sel.value;
  sel.innerHTML = '<option value="">All Categories</option>' + cats.map(c => `<option value="${c}">${c}</option>`).join('');
  sel.value = cur;
}

/* ── Budgets Render ────────────────────────────────────────── */
function renderBudgets() {
  const el  = document.getElementById('budget-list');
  const lbl = document.getElementById('budget-month-label');
  if (!el) return;
  if (lbl) lbl.textContent = new Date().toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  const entries = Object.entries(DB.budgets);
  if (!entries.length) {
    el.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-wallet"></i></div><h3>No budgets set</h3><p>Use the form to set monthly limits</p></div>`;
    return;
  }

  const now = new Date(), m = now.getMonth(), y = now.getFullYear();
  const monthExp = DB.transactions.filter(t => {
    const d = new Date(t.date);
    return t.type === 'expense' && d.getMonth() === m && d.getFullYear() === y;
  });

  el.innerHTML = entries.map(([cat, { limit, alertPct }]) => {
    const spent = monthExp.filter(t => t.category === cat).reduce((s,t) => s + t.amount, 0);
    const pct   = Math.round(spent / limit * 100);
    const over  = pct >= 100;
    const warn  = !over && pct >= alertPct && DB.settings.budgetAlerts;
    const color = over ? 'var(--expense)' : pct >= (alertPct || 80) ? 'var(--gold)' : 'var(--income)';
    return `
      <div class="budget-row">
        <div class="budget-meta">
          <div class="budget-name">
            <div class="legend-dot" style="background:${CAT_COLORS[cat] || '#64748b'}"></div>
            ${cat}
          </div>
          <span class="budget-pct" style="color:${color}">${pct}%</span>
        </div>
        <div class="progress"><div class="progress-fill" style="width:${Math.min(100, pct)}%;background:${color}"></div></div>
        <div class="budget-sub">
          <span>${fmt(spent)} spent</span>
          <span>${over ? `<span style="color:var(--expense)">Over by ${fmt(spent - limit)}</span>` : `${fmt(limit - spent)} remaining`}</span>
        </div>
        ${over ? `<div class="budget-alert budget-over"><i class="fas fa-circle-exclamation"></i> Over budget by ${fmt(spent - limit)}</div>` : ''}
        ${warn ? `<div class="budget-alert"><i class="fas fa-triangle-exclamation"></i> ${pct}% of budget used — approaching limit</div>` : ''}
        <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
          <span style="font-size:.72rem;color:var(--muted)">Limit: ${fmt(limit)}</span>
          <button class="btn btn-danger btn-sm" style="margin-left:auto" onclick="deleteBudget('${cat}')"><i class="fas fa-trash"></i></button>
        </div>
      </div>
    `;
  }).join('');
}

/* ── Goals Render ──────────────────────────────────────────── */
function renderGoals() {
  const el = document.getElementById('goals-list');
  if (!el) return;
  if (!DB.goals.length) {
    el.innerHTML = `<div class="empty-state"><div class="empty-icon"><i class="fas fa-bullseye"></i></div><h3>No savings goals</h3><p>Add your first goal using the form</p></div>`;
    return;
  }
  const priorityColor = { high: 'var(--expense)', medium: 'var(--gold)', low: 'var(--income)' };
  el.innerHTML = DB.goals.map(g => {
    const pct      = Math.min(100, Math.round(g.saved / g.target * 100));
    const daysLeft = g.date ? Math.ceil((new Date(g.date) - new Date()) / 86400000) : null;
    const done     = pct >= 100;
    return `
      <div class="goal-card">
        <div class="goal-head">
          <div>
            <div class="goal-name" style="${done ? 'color:var(--income)' : ''}">
              ${done ? '✅ ' : ''}${escHtml(g.name)}
              <span style="font-size:.65rem;font-weight:700;padding:2px 8px;border-radius:99px;border:1px solid;color:${priorityColor[g.priority]};border-color:${priorityColor[g.priority]}33;background:${priorityColor[g.priority]}11;margin-left:6px">${g.priority}</span>
            </div>
            <div class="goal-target">${g.desc ? escHtml(g.desc) : ''}</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-ghost btn-icon btn-sm" onclick="updateGoalSaved('${g.id}')" title="Update saved amount"><i class="fas fa-plus"></i></button>
            <button class="btn btn-danger btn-icon btn-sm" onclick="deleteGoal('${g.id}')"><i class="fas fa-trash"></i></button>
          </div>
        </div>
        <div class="progress" style="height:8px">
          <div class="progress-fill" style="width:${pct}%;background:${done ? 'var(--income)' : 'linear-gradient(90deg,var(--accent2),var(--accent))'}"></div>
        </div>
        <div class="goal-pct-row" style="margin-top:6px">
          <span style="font-size:.72rem;font-weight:700;color:${done ? 'var(--income)' : 'var(--accent)'}">${pct}%</span>
          <span style="font-size:.72rem;color:var(--muted)">${fmt(g.saved)} / ${fmt(g.target)}</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.72rem;color:var(--muted);margin-top:4px">
          <span>${fmt(Math.max(0, g.target - g.saved))} remaining</span>
          ${daysLeft !== null ? `<span>${daysLeft > 0 ? daysLeft + ' days left' : daysLeft === 0 ? 'Due today' : '<span style="color:var(--expense)">Overdue</span>'}</span>` : ''}
        </div>
      </div>
    `;
  }).join('');
}

/* ── Recurring Render ──────────────────────────────────────── */
function renderRecurring() {
  const el  = document.getElementById('rec-list');
  const cnt = document.getElementById('rec-count');
  if (!el) return;

  const recInc = DB.recurring.filter(r => r.type === 'income').reduce((s,r) => s + r.amount, 0);
  const recExp = DB.recurring.filter(r => r.type === 'expense').reduce((s,r) => s + r.amount, 0);
  const net    = recInc - recExp;

  const sumEl = document.getElementById('rec-summary');
  if (sumEl) {
    sumEl.innerHTML = `
      <div class="card-head"><div class="card-title-lg">Monthly Overview</div></div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;text-align:center">
        <div><div style="font-size:.68rem;color:var(--muted);margin-bottom:4px">RECURRING IN</div><div style="font-family:var(--fm);font-weight:700;color:var(--income)">${fmt(recInc)}</div></div>
        <div><div style="font-size:.68rem;color:var(--muted);margin-bottom:4px">RECURRING OUT</div><div style="font-family:var(--fm);font-weight:700;color:var(--expense)">${fmt(recExp)}</div></div>
        <div><div style="font-size:.68rem;color:var(--muted);margin-bottom:4px">NET/MONTH</div><div style="font-family:var(--fm);font-weight:700;color:${net >= 0 ? 'var(--income)' : 'var(--expense)'}">${net >= 0 ? '+' : ''}${fmt(net)}</div></div>
      </div>
    `;
  }

  if (!DB.recurring.length) {
    el.innerHTML = `<div class="empty-state" style="padding:36px 0"><div class="empty-icon"><i class="fas fa-rotate"></i></div><h3>No recurring items</h3><p>Add subscriptions, rent, or salary</p></div>`;
    if (cnt) cnt.textContent = ''; return;
  }
  if (cnt) cnt.textContent = `${DB.recurring.length} item${DB.recurring.length !== 1 ? 's' : ''}`;

  const freqLabel = { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', quarterly: 'Quarterly', yearly: 'Yearly' };
  el.innerHTML = DB.recurring.map(r => `
    <div class="rec-item">
      <div class="rec-icon" style="background:${r.type === 'income' ? 'rgba(0,212,170,.12)' : 'rgba(255,107,107,.12)'}">
        <i class="fas ${CAT_ICONS[r.category] || 'fa-rotate'}" style="color:${r.type === 'income' ? 'var(--income)' : 'var(--expense)'}"></i>
      </div>
      <div class="rec-info">
        <div class="rec-name">${escHtml(r.name)}<span class="freq-pill">${freqLabel[r.frequency] || r.frequency}</span></div>
        <div class="rec-detail">${r.category} · ${r.type}${r.date ? ` · Due ${fmtDate(r.date)}` : ''}</div>
      </div>
      <div style="text-align:right">
        <div class="rec-amount ${r.type === 'income' ? 'col-income' : 'col-expense'}">${r.type === 'income' ? '+' : '-'}${fmt(r.amount)}</div>
        <button class="btn btn-danger btn-sm" style="margin-top:5px" onclick="deleteRecurring('${r.id}')"><i class="fas fa-trash"></i></button>
      </div>
    </div>
  `).join('');
}

/* ── Analytics ─────────────────────────────────────────────── */
function renderAnalytics() {
  // 12-month Line chart
  const months = getLast12Months();
  const incArr = months.map(m => getMonthTotal(m, 'income'));
  const expArr = months.map(m => getMonthTotal(m, 'expense'));

  destroyChart('line');
  const lctx = document.getElementById('chart-line');
  if (lctx) chartInstances.line = new Chart(lctx, {
    type: 'line',
    data: { labels: months.map(m => m.label), datasets: [
      { label: 'Income',   data: incArr, borderColor: '#00d4aa', backgroundColor: 'rgba(0,212,170,.08)',  fill: true, tension: .4, pointBackgroundColor: '#00d4aa', pointRadius: 4, pointHoverRadius: 6 },
      { label: 'Expenses', data: expArr, borderColor: '#ff6b6b', backgroundColor: 'rgba(255,107,107,.08)',fill: true, tension: .4, pointBackgroundColor: '#ff6b6b', pointRadius: 4, pointHoverRadius: 6 },
    ]},
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { labels: { color: '#94a3b8', font: { family: 'Outfit' } } },
        tooltip: {
          backgroundColor: '#1a2035', titleColor: '#e2e8f0', bodyColor: '#94a3b8',
          borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
          callbacks: { label: c => `${c.dataset.label}: ${fmt(c.raw)}` }
        }
      },
      scales: {
        x: { ticks: { color: '#64748b', font: { family: 'Outfit' } }, grid: { color: 'rgba(255,255,255,.04)' } },
        y: { ticks: { color: '#64748b', font: { family: 'Outfit' }, callback: v => sym() + abbreviate(v) }, grid: { color: 'rgba(255,255,255,.04)' }, beginAtZero: true }
      }
    }
  });

  // All-time donut
  const catT = {};
  DB.transactions.filter(t => t.type === 'expense').forEach(t => catT[t.category] = (catT[t.category] || 0) + t.amount);
  const dLabels = Object.keys(catT), dData = Object.values(catT);
  const dColors = dLabels.map(l => CAT_COLORS[l] || '#64748b');

  destroyChart('donut');
  const dctx = document.getElementById('chart-donut');
  if (dctx) chartInstances.donut = new Chart(dctx, {
    type: 'doughnut',
    data: { labels: dLabels, datasets: [{ data: dData, backgroundColor: dColors.map(c => c + 'bb'), borderColor: dColors, borderWidth: 2, hoverOffset: 8 }] },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '62%',
      plugins: {
        legend: { labels: { color: '#94a3b8', font: { family: 'Outfit', size: 11 } } },
        tooltip: {
          backgroundColor: '#1a2035', titleColor: '#e2e8f0', bodyColor: '#94a3b8',
          borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
          callbacks: { label: c => `${c.label}: ${fmt(c.raw)}` }
        }
      }
    }
  });

  // Daily bar — last 30 days
  const daily  = {}, cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 29);
  for (let d = new Date(cutoff); d <= new Date(); d.setDate(d.getDate() + 1)) {
    daily[d.toISOString().slice(0, 10)] = 0;
  }
  DB.transactions
    .filter(t => t.type === 'expense' && new Date(t.date) >= cutoff)
    .forEach(t => { daily[t.date] = (daily[t.date] || 0) + t.amount; });

  const dKeys = Object.keys(daily).sort(), dVals = dKeys.map(k => daily[k]);
  destroyChart('daily');
  const dyctx = document.getElementById('chart-daily');
  if (dyctx) chartInstances.daily = new Chart(dyctx, {
    type: 'bar',
    data: {
      labels: dKeys.map((d, i) => {
        const dt = new Date(d + 'T00:00:00');
        return dt.getDate() === 1 || i === 0 ? dt.toLocaleDateString('en', { month: 'short', day: 'numeric' }) : String(dt.getDate());
      }),
      datasets: [{
        label: 'Spending', data: dVals,
        backgroundColor: dVals.map(v => v > 0 ? 'rgba(255,107,107,.6)' : 'rgba(100,116,139,.2)'),
        borderColor:      dVals.map(v => v > 0 ? '#ff6b6b' : '#475569'),
        borderWidth: 1, borderRadius: 4
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1a2035', titleColor: '#e2e8f0', bodyColor: '#94a3b8',
          borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
          callbacks: { label: c => `Spent: ${fmt(c.raw)}` }
        }
      },
      scales: {
        x: { ticks: { color: '#64748b', font: { family: 'Outfit', size: 10 }, maxTicksLimit: 15 }, grid: { display: false } },
        y: { ticks: { color: '#64748b', font: { family: 'Outfit' }, callback: v => sym() + abbreviate(v) }, grid: { color: 'rgba(255,255,255,.04)' }, beginAtZero: true }
      }
    }
  });

  // Key metrics
  const allInc = DB.transactions.filter(t => t.type === 'income').reduce((s,t) => s + t.amount, 0);
  const allExp = DB.transactions.filter(t => t.type === 'expense').reduce((s,t) => s + t.amount, 0);
  const avg    = DB.transactions.filter(t => t.type === 'expense').length ? allExp / DB.transactions.filter(t => t.type === 'expense').length : 0;
  const maxTx  = DB.transactions.reduce((max,t) => t.amount > max.amount ? t : max, { amount: 0 });

  const metrics = document.getElementById('analytics-metrics');
  if (metrics) metrics.innerHTML = [
    ['Total Income',    fmt(allInc),  'var(--income)'],
    ['Total Expenses',  fmt(allExp),  'var(--expense)'],
    ['Net Balance',     fmt(allInc - allExp), allInc >= allExp ? 'var(--income)' : 'var(--expense)'],
    ['Avg Transaction', fmt(avg),     'var(--text)'],
    ['Total Records',   DB.transactions.length, 'var(--text)'],
    ['Largest Expense', maxTx.amount ? fmt(maxTx.amount) : '—', 'var(--gold)'],
  ].map(([l,v,c]) => `
    <div class="analytics-stat">
      <span class="label">${l}</span>
      <span class="value" style="color:${c}">${v}</span>
    </div>
  `).join('');

  // Top categories
  const topCats = document.getElementById('analytics-top-cats');
  const total   = Object.values(catT).reduce((s,v) => s + v, 0);
  const sorted  = Object.entries(catT).sort((a,b) => b[1] - a[1]).slice(0, 6);
  if (topCats) topCats.innerHTML = sorted.length ? sorted.map(([cat, amt]) => `
    <div class="legend-item">
      <div class="legend-dot" style="background:${CAT_COLORS[cat] || '#64748b'}"></div>
      <span style="flex:1">${cat}</span>
      <div class="legend-bar-wrap"><div class="legend-bar"><div class="legend-fill" style="width:${total ? Math.round(amt / total * 100) : 0}%;background:${CAT_COLORS[cat] || '#64748b'}"></div></div></div>
      <span class="legend-pct">${total ? Math.round(amt / total * 100) : 0}%</span>
      <span class="legend-amt">${fmt(amt)}</span>
    </div>
  `).join('') : '<div style="color:var(--muted);font-size:.8rem">No expense data yet</div>';
}

/* ── About / Settings ──────────────────────────────────────── */
function renderAbout() {
  const el = document.getElementById('about-stats');
  if (!el) return;
  const first = DB.transactions.length
    ? [...DB.transactions].sort((a,b) => a.date.localeCompare(b.date))[0].date
    : null;
  el.innerHTML = [
    ['Transactions',    DB.transactions.length],
    ['Budgets set',     Object.keys(DB.budgets).length],
    ['Savings goals',   DB.goals.length],
    ['Recurring items', DB.recurring.length],
    ['Tracking since',  first ? fmtDate(first) : '—'],
    ['Version',         'Spendly v3.0'],
  ].map(([l,v]) => `
    <div class="analytics-stat">
      <span class="label">${l}</span>
      <span class="value">${v}</span>
    </div>
  `).join('');
}

/* ── Utility Functions ─────────────────────────────────────── */
function getLast6Months() {
  const now = new Date(), res = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    res.push({ label: d.toLocaleDateString('en', { month: 'short', year: '2-digit' }), month: d.getMonth(), year: d.getFullYear() });
  }
  return res;
}

function getLast12Months() {
  const now = new Date(), res = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    res.push({ label: d.toLocaleDateString('en', { month: 'short' }), month: d.getMonth(), year: d.getFullYear() });
  }
  return res;
}

function getMonthTotal({ month, year }, type) {
  return DB.transactions
    .filter(t => { const d = new Date(t.date); return t.type === type && d.getMonth() === month && d.getFullYear() === year; })
    .reduce((s,t) => s + t.amount, 0);
}

function destroyChart(k) {
  if (chartInstances[k]) { chartInstances[k].destroy(); delete chartInstances[k]; }
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function fmtDate(d) {
  return new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function escHtml(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function abbreviate(v) {
  if (v >= 1e7) return (v / 1e7).toFixed(1) + 'Cr';
  if (v >= 1e5) return (v / 1e5).toFixed(1) + 'L';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + 'K';
  return v;
}

/* ── Toast Notifications ───────────────────────────────────── */
function toast(msg, type = 'info', duration = 3000) {
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', info: 'fa-circle-info' };
  const el    = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => {
    el.style.opacity   = '0';
    el.style.transform = 'translateX(30px)';
    el.style.transition = 'all .3s';
    setTimeout(() => el.remove(), 300);
  }, duration);
}

/* ── Keyboard Shortcuts ────────────────────────────────────── */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeModal(); closeConfirm(); }
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    if (document.getElementById('modal-overlay').classList.contains('open')) saveTransaction();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
    e.preventDefault(); openModal();
  }
});

/* ── Seed Sample Data ──────────────────────────────────────── */
function seedSample() {
  if (DB.transactions.length > 0) return;

  const today  = new Date();
  const d = offset => { const dt = new Date(today); dt.setDate(dt.getDate() + offset); return dt.toISOString().slice(0, 10); };

  const samples = [
    { type:'income',  category:'Salary',         amount:55000, description:'Monthly Salary',        date:d(-1),  payment:'Bank Transfer', tags:['monthly'] },
    { type:'expense', category:'Housing',         amount:12000, description:'House Rent',            date:d(-1),  payment:'Bank Transfer', tags:['monthly','fixed'] },
    { type:'expense', category:'Food',            amount:450,   description:'Lunch at office',       date:d(0),   payment:'UPI / GPay',    tags:['work'] },
    { type:'expense', category:'Transportation',  amount:280,   description:'Cab to office',         date:d(0),   payment:'UPI / GPay',    tags:['work'] },
    { type:'expense', category:'Entertainment',   amount:649,   description:'Netflix subscription',  date:d(-3),  payment:'Card',          tags:['subscription'] },
    { type:'expense', category:'Utilities',       amount:1200,  description:'Electricity bill',      date:d(-5),  payment:'UPI / GPay',    tags:['monthly'] },
    { type:'income',  category:'Freelance',       amount:12000, description:'Website redesign',      date:d(-7),  payment:'Bank Transfer', tags:['freelance','design'] },
    { type:'expense', category:'Shopping',        amount:2800,  description:'New sneakers',          date:d(-8),  payment:'Card',          tags:['clothing'] },
    { type:'expense', category:'Healthcare',      amount:500,   description:'Doctor consultation',   date:d(-10), payment:'Cash',          tags:[] },
    { type:'expense', category:'Education',       amount:1999,  description:'Udemy course',          date:d(-12), payment:'Card',          tags:['learning'] },
    { type:'expense', category:'Food',            amount:320,   description:'Groceries',             date:d(-2),  payment:'Cash',          tags:['weekly'] },
    { type:'expense', category:'Entertainment',   amount:199,   description:'Spotify Premium',       date:d(-15), payment:'Card',          tags:['subscription','music'] },
    { type:'expense', category:'Food',            amount:750,   description:'Dinner with friends',   date:d(-6),  payment:'UPI / GPay',    tags:['social'] },
    { type:'income',  category:'Investment',      amount:3500,  description:'Dividend income',       date:d(-20), payment:'Bank Transfer', tags:['passive'] },
    { type:'expense', category:'Transportation',  amount:1500,  description:'Petrol monthly fill',   date:d(-4),  payment:'Card',          tags:['monthly'] },
  ];

  // Historical (previous month)
  const prevMonth = String(new Date().getMonth()).padStart(2, '0');
  const prevYear  = new Date().getFullYear();
  const hist = [
    { type:'income',  category:'Salary',  amount:55000, description:'Salary — Previous Month', date:`${prevYear}-${prevMonth}-01`, payment:'Bank Transfer', tags:['monthly'] },
    { type:'expense', category:'Housing', amount:12000, description:'Rent — Previous Month',   date:`${prevYear}-${prevMonth}-02`, payment:'Bank Transfer', tags:['monthly'] },
    { type:'expense', category:'Food',    amount:5200,  description:'Food & groceries',         date:`${prevYear}-${prevMonth}-15`, payment:'Mixed',         tags:[] },
    { type:'expense', category:'Shopping',amount:3400,  description:'Shopping',                 date:`${prevYear}-${prevMonth}-20`, payment:'Card',          tags:[] },
  ];

  [...samples, ...hist].forEach(s => DB.transactions.push({
    id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: Date.now(), notes: '', ...s,
  }));

  DB.budgets = {
    Food:          { limit: 6000,  alertPct: 80 },
    Housing:       { limit: 14000, alertPct: 90 },
    Entertainment: { limit: 2000,  alertPct: 75 },
    Transportation:{ limit: 3000,  alertPct: 80 },
    Shopping:      { limit: 5000,  alertPct: 70 },
  };

  DB.goals = [
    { id: 'g1', name: 'Emergency Fund', target: 100000, saved: 35000, date: '2025-12-31', priority: 'high',   desc: '6 months of expenses',     createdAt: Date.now() },
    { id: 'g2', name: 'Vacation — Goa', target: 25000,  saved: 8000,  date: '2025-06-30', priority: 'medium', desc: 'Beach vacation with family', createdAt: Date.now() },
    { id: 'g3', name: 'New Laptop',     target: 80000,  saved: 20000, date: '2025-09-01', priority: 'medium', desc: 'MacBook Pro M4',             createdAt: Date.now() },
  ];

  DB.recurring = [
    { id: 'r1', name: 'House Rent',     category: 'Housing',       frequency: 'monthly', amount: 12000, type: 'expense', date: '', createdAt: Date.now() },
    { id: 'r2', name: 'Netflix',        category: 'Entertainment', frequency: 'monthly', amount: 649,   type: 'expense', date: '', createdAt: Date.now() },
    { id: 'r3', name: 'Spotify',        category: 'Entertainment', frequency: 'monthly', amount: 199,   type: 'expense', date: '', createdAt: Date.now() },
    { id: 'r4', name: 'Monthly Salary', category: 'Salary',        frequency: 'monthly', amount: 55000, type: 'income',  date: '', createdAt: Date.now() },
  ];

  DB.settings = { ...DB.settings, name: '', monthlyIncome: 55000 };
  persist();
}

/* ── Application Init ──────────────────────────────────────── */
(function init() {
  loadDB();
  seedSample();
  applySettings();
  updateGreeting();
  renderAll();

  // Set today's date in forms
  const mDate = document.getElementById('m-date'); if (mDate) mDate.value = todayStr();
  const rDate = document.getElementById('r-date'); if (rDate) rDate.value = todayStr();

  // Set initial modal type
  setType('expense');

  console.log(`Spendly v3 initialized ✓ — ${DB.transactions.length} transactions loaded`);
})();
